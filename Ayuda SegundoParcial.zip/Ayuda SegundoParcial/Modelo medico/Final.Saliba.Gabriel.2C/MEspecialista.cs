﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class MEspecialista : Medico, IMedico
    {
        private Especialidad especialidad;

        protected override void Atender()
        {
            Thread.Sleep(tiempoAleatorio.Next(5000, 10000));
            this.FinalizarAtencion();
        }

        public void IniciarAtencion(Paciente p)
        {
            Thread hilo = new Thread(Atender);
            base.AtenderA = p;
            hilo.Start();
        }

        public MEspecialista(string nombre, string apellido, Especialidad e) : base(nombre, apellido)
        {
            this.especialidad = e;
        }


        public enum Especialidad
        {
            Traumatologo,
            Odontologo
        }
    }
}
