﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Medico :  Persona
    {
        private Paciente pacienteActual;
        static protected Random tiempoAleatorio;

        public Paciente AtenderA
        {
            set
            {
                pacienteActual = value;
            }
        }

        public virtual string EstaAtendiendoA
        {
            get
            {
                return pacienteActual.ToString();
            }
        }

        protected abstract void Atender();


        protected void FinalizarAtencion()
        {
            this.AtencionFinalizada(pacienteActual, this);
            this.pacienteActual = null;
        }

        static Medico()
        {
            tiempoAleatorio = new Random();
        }

        public Medico(string nombre, string apellido) : base(nombre, apellido)
        {
            
        }

        public event FinAtencionPaciente AtencionFinalizada;
        public delegate void FinAtencionPaciente(Paciente p, Medico m);

    }
}
