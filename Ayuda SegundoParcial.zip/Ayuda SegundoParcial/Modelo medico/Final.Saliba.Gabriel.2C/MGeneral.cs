﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class MGeneral : Medico, IMedico
    {
        protected override void Atender()
        {
            Thread.Sleep(tiempoAleatorio.Next(1500, 2200));
            this.FinalizarAtencion();
        }
        public void IniciarAtencion(Paciente p)
        {
            Thread hilo = new Thread(Atender);
            base.AtenderA = p;
            hilo.Start();
        }

        public MGeneral(string nombre, string apellido) : base(nombre, apellido)
        {

        }
    }
}
