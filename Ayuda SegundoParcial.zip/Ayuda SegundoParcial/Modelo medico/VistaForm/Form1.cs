﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Threading;


namespace VistaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.medicoGeneral = new MGeneral("Luis", "Salinas");
            this.medicoEspecialista = new MEspecialista("Jorge", "Iglesias",
            MEspecialista.Especialidad.Traumatologo);
            pacientesEnEspera = new Queue<Paciente>();
        }
        private MEspecialista medicoEspecialista;
        private MGeneral medicoGeneral;
        private Thread mocker;
        private Queue<Paciente> pacientesEnEspera;

        private void AtenderPacientes(IMedico iMedico)
        {
            Paciente pacienteAux = pacientesEnEspera.Dequeue();
            iMedico.IniciarAtencion(pacienteAux);
            FinAtencion(pacienteAux, (Medico)iMedico);
        }

        private void FinAtencion(Paciente p, Medico m)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((MethodInvoker)delegate ()
                {
                    MessageBox.Show(string.Format("Finalizó la atención de {0} por {1}!", p.ToString(), m.ToString()));
                }
                );
            }
            else
            {
                MessageBox.Show(string.Format("Finalizó la atención de {0} por {1}!", p.ToString(), m.ToString()));
            }
        }

        private void MockPacientes()
        {
            Paciente p1 = new Paciente("Alejandro", "Planes");
            Paciente p2 = new Paciente("Damian", "Desario");
            pacientesEnEspera.Enqueue(p1);
            Thread.Sleep(5000);
            pacientesEnEspera.Enqueue(p2);
        }

        private void btnAtenderMGeneral_Click(object sender, EventArgs e)
        {
            this.medicoGeneral.AtencionFinalizada += FinAtencion;
            if (this.pacientesEnEspera.Count > 0)
            {
                AtenderPacientes(this.medicoGeneral);
            }
        }

        private void btnAtenderEMedico_Click(object sender, EventArgs e)
        {
            this.medicoEspecialista.AtencionFinalizada += FinAtencion;

            if (this.pacientesEnEspera.Count > 0)
            {
                AtenderPacientes(this.medicoEspecialista);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.mocker = new Thread(MockPacientes);
            mocker.Start();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.mocker.IsAlive)
            {
                this.mocker.Abort();
            }
        }
    }
}
