﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using interfaces;
using System.IO;

namespace Entidades
{
    public class LosHilos : IRespuesta<int>
    {
        StreamWriter streamWriter;
        StreamReader streamReader;

        private int id;
        private List<InfoHilo> misHilos;

        public event DelegadoAvisoFin AvisoFin;
        public delegate void DelegadoAvisoFin(string mensaje);

        public string Bitacora
        {
            get
            {
                try
                {
                    string rutaArchivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\bitacora.txt";

                    streamReader = new StreamReader(rutaArchivo); //Especifico de donde leo los datos.

                    return  streamReader.ReadToEnd(); //Lee todo el archivo hasta el final 
                                                         //y lo retorna como una cadena de caracteres al parametro recibido (datos).
                }
                catch (Exception exception)
                {

                    throw exception;
                }
                finally
                {
                    streamReader.Close();
                }
            }
            set
            {
                try
                {
                    string rutaArchivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\bitacora.txt";
                    streamWriter = new StreamWriter(rutaArchivo, true); // si append es true, se agregarán datos al archivo exis
                    streamWriter.WriteLine(value); //Escribe los datos en el archivo provocando salto de línea.
                    streamWriter.Close(); //Cierra el objeto StreamWriter.
                }
                catch (Exception exception)
                {
                    throw exception;
                }
                finally
                {
                    streamWriter.Close();
                }
            }
        }

        static LosHilos AgregarHilo(LosHilos hilos)
        {
            hilos.id++;
            InfoHilo infoHilos = new InfoHilo(hilos.id, hilos);

            hilos.misHilos.Add(infoHilos);
            
            return hilos;
        }

        public LosHilos()
        {
            this.id = 0;
            this.misHilos = new List<InfoHilo>();
        }

        public static LosHilos operator +(LosHilos hilos, int cantidad)
        {
            if (cantidad < 1)
            {
                throw new CantidadInvalidaException();
            }
            else if (cantidad > 0)
            {
                for (int i = 0; i < cantidad; i++)
                {
                    AgregarHilo(hilos);
                }
            }
            return hilos;
        }

        public void RespuestaHilo(int id)
        {
            string mensaje = "";
            mensaje = string.Format("Termino el hilo {0}.", id);
            this.Bitacora = mensaje;
            this.AvisoFin(mensaje);
        }
    }
}
