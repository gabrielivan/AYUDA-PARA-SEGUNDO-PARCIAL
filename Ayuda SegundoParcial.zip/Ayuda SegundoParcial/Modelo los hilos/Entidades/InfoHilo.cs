﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using interfaces;
using System.Threading;


namespace Entidades
{
    public class InfoHilo
    {
        private IRespuesta<int> callBack;
        private Thread hilo;
        private int id;
        static Random randomizer;

        private void Ejecutar()
        {
            Thread.Sleep(randomizer.Next(1000, 5000));
            callBack.RespuestaHilo(this.id);
            
        }
        private InfoHilo()
        {
            randomizer = new Random();
            this.hilo = new Thread(Ejecutar);
            hilo.Start();
        }

        public InfoHilo(int id, IRespuesta<int> callBack) : this()
        {
            this.id = id;
            this.callBack = callBack;
        }

    }
}
