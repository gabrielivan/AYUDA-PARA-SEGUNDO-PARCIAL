﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Threading;

namespace Saliba.Gabriel._2C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            hilos = new LosHilos();
            hilos.AvisoFin += MostrarMensajeFin;
        }

        private LosHilos hilos;

        public void MostrarMensajeFin(string mensaje)
        {
            MessageBox.Show(mensaje);
        }

        private void btnLanzar_Click(object sender, EventArgs e)
        {
            try
            {
                hilos += 1;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        private void btnBitacora_Click(object sender, EventArgs e)
        {
            string mensaje = hilos.Bitacora;
            MessageBox.Show(mensaje);
        }

    }
}
