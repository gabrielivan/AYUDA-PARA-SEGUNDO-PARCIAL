using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
    public class Sql : IArchivo<Queue<Patente>>
    {
        private SqlCommand comando;
        private SqlConnection conexion;

        public void Guardar(string tabla, Queue<Patente> datos)
        {
            try
            {
                foreach (var dato in datos)
                {
                    string consulta = String.Format("INSERT INTO '{0}' VALUES ('{1}, {2}')",
                                                     tabla, dato.CodigoPatente, dato.TipoCodigo);
                    comando.CommandText = consulta;
                    conexion.Open();
                    comando.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (conexion.State == ConnectionState.Open)
                    conexion.Close();
            }
        }
        public void Leer(string tabla, out Queue<Patente> datos)
        {
            datos = new Queue<Patente>();
            string codigo;
            Patente.Tipo tipoCodigo;
            string consulta = String.Format("Select * from '{0}'", tabla);
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                SqlDataReader oDr = comando.ExecuteReader();

                while (oDr.Read())
                {
                    codigo = (oDr["Codigo"].ToString());
                    tipoCodigo = (Patente.Tipo)oDr["TipoCodigo"];
                    Patente patente = new Patente(codigo, tipoCodigo);
                    datos.Enqueue(patente);
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                if (conexion.State == ConnectionState.Open)
                    conexion.Close();
            }

        }
        public Sql()
        {
            string connectionStr = @"Data Source=.\SQLEXPRESS; Initial Catalog=Patentes; Integrated Security = True";

            try
            {
                conexion = new SqlConnection(connectionStr);
                comando = new SqlCommand();
                comando.CommandType = System.Data.CommandType.Text;
                comando.Connection = conexion;
            }
            catch (Exception e)
            {
                throw e;
            }

        }
    }
}
