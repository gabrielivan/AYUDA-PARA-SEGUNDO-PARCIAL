﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Entidades;

namespace Archivos
{
    public class Texto : IArchivo<Queue<Patente>>
    {
        StreamWriter streamWriter;
        StreamReader streamReader;

        public void Guardar(string archivo, Queue<Patente> datos)
        {
            try
            {
                streamWriter = new StreamWriter(archivo, true); // si append es true, se agregarán datos al archivo exis
                streamWriter.WriteLine(datos); //Escribe los datos en el archivo provocando salto de línea.
                streamWriter.Close(); //Cierra el objeto StreamWriter.

            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                streamWriter.Close();
            }
        }
        public void Leer(string archivo, out Queue<Patente> datos)
        {
            datos = new Queue<Patente>();
            try
            {
                streamReader = new StreamReader(archivo); //Especifico de donde leo los datos.

                datos.Enqueue(streamReader.ReadLine().ValidarPatente()); //Lee todo el archivo hasta el final 
                                                  //y lo retorna como una cadena de caracteres al parametro recibido (datos).
                streamReader.Close(); //Cierro el archivo.

            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                streamReader.Close();
            }
            datos = new Queue<Patente>();
        }
    }
}
