﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades;
using Archivos;
using System.Threading;

namespace _20181122_SP
{
    public partial class FrmPpal : Form
    {
        Queue<Patente> cola;
        private List<Thread> hilos;

        public FrmPpal()
        {
            InitializeComponent();

            this.cola = new Queue<Patente>();
            hilos = new List<Thread>();
        }

        private void FrmPpal_Load(object sender, EventArgs e)
        {
            vistaPatente1.finExposicion += ProximaPatente;
            vistaPatente2.finExposicion += ProximaPatente;
        }

        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.FinalizarSimulacion();
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
            try
            {
                Xml<Queue<Patente>> patente = new Xml<Queue<Patente>>();
                patente.Leer(@"D:\VisualStudio\20181122-SP\patentes.xml", out cola);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
            try
            {
                Texto texto = new Texto();
                texto.Leer(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\patentes.txt", out this.cola);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
            this.IniciarSimulacion();
        }

        private void btnSql_Click(object sender, EventArgs e)
        {
            try
            {
                Sql sql = new Sql();
                sql.Leer("Patentes", out this.cola);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.IniciarSimulacion();
        }

        private void FinalizarSimulacion()
        {
            foreach (Thread hilo in hilos)
            {
                hilo.Abort();
            }
        }

        private void IniciarSimulacion()
        {
            foreach (Thread hilo in hilos)
            {
                if (hilo.IsAlive)
                {
                    hilo.Abort();
                }
            }

            this.ProximaPatente(vistaPatente1);
            this.ProximaPatente(vistaPatente2);
        }

        public void ProximaPatente(Patentes.VistaPatente vp)
        {
            if (this.cola.Count > 0)
            {
                Thread t = new Thread(new ParameterizedThreadStart(vp.MostrarPatente));
                t.Start(this.cola.Dequeue());
                this.hilos.Add(t);
            }
        }
    }
}
