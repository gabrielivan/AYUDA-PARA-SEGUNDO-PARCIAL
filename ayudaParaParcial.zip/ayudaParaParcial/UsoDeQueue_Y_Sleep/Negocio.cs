﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio31
{
    class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;

        public Cliente Cliente
        {
            get
            {
                if (clientes.Count != 0)
                {
                    return clientes.Dequeue();
                }
                else
                {
                    return null;
                }
            }

            set
            {
                bool trueOrFalse = this + value;
            }
        }

        private Negocio()
        {
            clientes = new Queue<Cliente>();
            caja = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
        }

        public Negocio(string nombre)
        {

        }

        public static bool operator ==(Negocio n, Cliente c)
        {
            bool retorno = false;

            foreach (var cliente in n.clientes)
            {
                if (cliente == c)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Negocio n, Cliente c)
        {
            return  !(n == c);
        }

        public static bool operator +(Negocio n, Cliente c)
        {
            bool retorno = false;

            if (n != c)
            {
                n.clientes.Enqueue(c);
                retorno = true;
            }

            return retorno;
        }

        public static bool operator ~(Negocio n)
        {
            bool retorno = false;

            Cliente newCliente = n.Cliente;

            PuestoAtencion puestoAtencion = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);
            puestoAtencion.Atender(newCliente);

            return retorno;
        }

    }
}
