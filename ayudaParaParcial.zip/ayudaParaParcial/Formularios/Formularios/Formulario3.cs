﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Formulario3 : Form
    {
        public Formulario3()
        {
            InitializeComponent();
        }

        public Formulario3(string resultadoForms) : this()
        {
            LblResultado.Text = resultadoForms;
        }

        private void btnVolverPrimerForm_Click(object sender, EventArgs e)
        {
            Formulario1 formularioUno = new Formulario1();
            formularioUno.Visible = true;
            this.Visible = false;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Visible = false;
        }
    }
}
