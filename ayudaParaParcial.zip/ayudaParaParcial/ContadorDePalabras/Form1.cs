﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContadorDePalabras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> contadorDePalabras = new Dictionary<string, int>();
            char [] delimitador = new char[5];
            delimitador[0] = ' ';
            delimitador[1] = '.';
            delimitador[2] = ',';
            delimitador[3] = '\n';
            string [] palabras = rtbTexto.Text.Split(delimitador);

            foreach (var palabra in palabras)
            {
                if (!contadorDePalabras.ContainsKey(palabra))
                {
                    contadorDePalabras.Add(palabra, 1);
                }
                else
                {
                    contadorDePalabras[palabra] += 1;
                }

            }

            contadorDePalabras = contadorDePalabras.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            foreach (KeyValuePair<string, int> palabra in contadorDePalabras)
            {
                MessageBox.Show(palabra.Key + "\n" + palabra.Value);
            }

        }
    }
}
