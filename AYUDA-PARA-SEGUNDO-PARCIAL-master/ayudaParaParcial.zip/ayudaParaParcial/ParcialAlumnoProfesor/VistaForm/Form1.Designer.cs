﻿namespace VistaForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxDatosCurso = new System.Windows.Forms.GroupBox();
            this.txtBoxDniCurso = new System.Windows.Forms.TextBox();
            this.dateTimePickerIngreso = new System.Windows.Forms.DateTimePicker();
            this.txtBoxApellidoCurso = new System.Windows.Forms.TextBox();
            this.txtNombreCurso = new System.Windows.Forms.TextBox();
            this.comboBoxDivisonCurso = new System.Windows.Forms.ComboBox();
            this.numericUpDownAñoCurso = new System.Windows.Forms.NumericUpDown();
            this.lblDni = new System.Windows.Forms.Label();
            this.lblIngreso = new System.Windows.Forms.Label();
            this.lblApellido = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblDivision = new System.Windows.Forms.Label();
            this.lblAño = new System.Windows.Forms.Label();
            this.groupBoxDatosAlumno = new System.Windows.Forms.GroupBox();
            this.comboBoxDivisonAlumno = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBoxLegajo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUpDownAñoAlumno = new System.Windows.Forms.NumericUpDown();
            this.txtBoxApellidoAlumno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxNombreAlumno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCrearCurso = new System.Windows.Forms.Button();
            this.brnMostrarCurso = new System.Windows.Forms.Button();
            this.btnAgregarAlumno = new System.Windows.Forms.Button();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.groupBoxDatosCurso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAñoCurso)).BeginInit();
            this.groupBoxDatosAlumno.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAñoAlumno)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxDatosCurso
            // 
            this.groupBoxDatosCurso.Controls.Add(this.txtBoxDniCurso);
            this.groupBoxDatosCurso.Controls.Add(this.dateTimePickerIngreso);
            this.groupBoxDatosCurso.Controls.Add(this.txtBoxApellidoCurso);
            this.groupBoxDatosCurso.Controls.Add(this.txtNombreCurso);
            this.groupBoxDatosCurso.Controls.Add(this.comboBoxDivisonCurso);
            this.groupBoxDatosCurso.Controls.Add(this.numericUpDownAñoCurso);
            this.groupBoxDatosCurso.Controls.Add(this.lblDni);
            this.groupBoxDatosCurso.Controls.Add(this.lblIngreso);
            this.groupBoxDatosCurso.Controls.Add(this.lblApellido);
            this.groupBoxDatosCurso.Controls.Add(this.lblNombre);
            this.groupBoxDatosCurso.Controls.Add(this.lblDivision);
            this.groupBoxDatosCurso.Controls.Add(this.lblAño);
            this.groupBoxDatosCurso.Location = new System.Drawing.Point(12, 12);
            this.groupBoxDatosCurso.Name = "groupBoxDatosCurso";
            this.groupBoxDatosCurso.Size = new System.Drawing.Size(200, 184);
            this.groupBoxDatosCurso.TabIndex = 0;
            this.groupBoxDatosCurso.TabStop = false;
            this.groupBoxDatosCurso.Text = "Datos Curso";
            // 
            // txtBoxDniCurso
            // 
            this.txtBoxDniCurso.Location = new System.Drawing.Point(56, 128);
            this.txtBoxDniCurso.Name = "txtBoxDniCurso";
            this.txtBoxDniCurso.Size = new System.Drawing.Size(120, 20);
            this.txtBoxDniCurso.TabIndex = 11;
            // 
            // dateTimePickerIngreso
            // 
            this.dateTimePickerIngreso.Location = new System.Drawing.Point(55, 154);
            this.dateTimePickerIngreso.Name = "dateTimePickerIngreso";
            this.dateTimePickerIngreso.Size = new System.Drawing.Size(120, 20);
            this.dateTimePickerIngreso.TabIndex = 10;
            // 
            // txtBoxApellidoCurso
            // 
            this.txtBoxApellidoCurso.Location = new System.Drawing.Point(56, 102);
            this.txtBoxApellidoCurso.Name = "txtBoxApellidoCurso";
            this.txtBoxApellidoCurso.Size = new System.Drawing.Size(120, 20);
            this.txtBoxApellidoCurso.TabIndex = 9;
            // 
            // txtNombreCurso
            // 
            this.txtNombreCurso.Location = new System.Drawing.Point(56, 76);
            this.txtNombreCurso.Name = "txtNombreCurso";
            this.txtNombreCurso.Size = new System.Drawing.Size(120, 20);
            this.txtNombreCurso.TabIndex = 8;
            // 
            // comboBoxDivisonCurso
            // 
            this.comboBoxDivisonCurso.FormattingEnabled = true;
            this.comboBoxDivisonCurso.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E"});
            this.comboBoxDivisonCurso.Location = new System.Drawing.Point(55, 49);
            this.comboBoxDivisonCurso.Name = "comboBoxDivisonCurso";
            this.comboBoxDivisonCurso.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDivisonCurso.TabIndex = 7;
            // 
            // numericUpDownAñoCurso
            // 
            this.numericUpDownAñoCurso.Location = new System.Drawing.Point(55, 23);
            this.numericUpDownAñoCurso.Name = "numericUpDownAñoCurso";
            this.numericUpDownAñoCurso.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownAñoCurso.TabIndex = 6;
            // 
            // lblDni
            // 
            this.lblDni.AutoSize = true;
            this.lblDni.Location = new System.Drawing.Point(10, 131);
            this.lblDni.Name = "lblDni";
            this.lblDni.Size = new System.Drawing.Size(26, 13);
            this.lblDni.TabIndex = 5;
            this.lblDni.Text = "DNI";
            // 
            // lblIngreso
            // 
            this.lblIngreso.AutoSize = true;
            this.lblIngreso.Location = new System.Drawing.Point(6, 160);
            this.lblIngreso.Name = "lblIngreso";
            this.lblIngreso.Size = new System.Drawing.Size(42, 13);
            this.lblIngreso.TabIndex = 4;
            this.lblIngreso.Text = "Ingreso";
            // 
            // lblApellido
            // 
            this.lblApellido.AutoSize = true;
            this.lblApellido.Location = new System.Drawing.Point(6, 105);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Size = new System.Drawing.Size(44, 13);
            this.lblApellido.TabIndex = 3;
            this.lblApellido.Text = "Apellido";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(6, 79);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(44, 13);
            this.lblNombre.TabIndex = 2;
            this.lblNombre.Text = "Nombre";
            // 
            // lblDivision
            // 
            this.lblDivision.AutoSize = true;
            this.lblDivision.Location = new System.Drawing.Point(6, 52);
            this.lblDivision.Name = "lblDivision";
            this.lblDivision.Size = new System.Drawing.Size(44, 13);
            this.lblDivision.TabIndex = 1;
            this.lblDivision.Text = "Division";
            // 
            // lblAño
            // 
            this.lblAño.AutoSize = true;
            this.lblAño.Location = new System.Drawing.Point(6, 30);
            this.lblAño.Name = "lblAño";
            this.lblAño.Size = new System.Drawing.Size(26, 13);
            this.lblAño.TabIndex = 0;
            this.lblAño.Text = "Año";
            // 
            // groupBoxDatosAlumno
            // 
            this.groupBoxDatosAlumno.Controls.Add(this.comboBoxDivisonAlumno);
            this.groupBoxDatosAlumno.Controls.Add(this.label5);
            this.groupBoxDatosAlumno.Controls.Add(this.txtBoxLegajo);
            this.groupBoxDatosAlumno.Controls.Add(this.label4);
            this.groupBoxDatosAlumno.Controls.Add(this.numericUpDownAñoAlumno);
            this.groupBoxDatosAlumno.Controls.Add(this.txtBoxApellidoAlumno);
            this.groupBoxDatosAlumno.Controls.Add(this.label3);
            this.groupBoxDatosAlumno.Controls.Add(this.txtBoxNombreAlumno);
            this.groupBoxDatosAlumno.Controls.Add(this.label2);
            this.groupBoxDatosAlumno.Controls.Add(this.label1);
            this.groupBoxDatosAlumno.Location = new System.Drawing.Point(240, 12);
            this.groupBoxDatosAlumno.Name = "groupBoxDatosAlumno";
            this.groupBoxDatosAlumno.Size = new System.Drawing.Size(201, 184);
            this.groupBoxDatosAlumno.TabIndex = 1;
            this.groupBoxDatosAlumno.TabStop = false;
            this.groupBoxDatosAlumno.Text = "Datos Alumno";
            // 
            // comboBoxDivisonAlumno
            // 
            this.comboBoxDivisonAlumno.FormattingEnabled = true;
            this.comboBoxDivisonAlumno.Location = new System.Drawing.Point(55, 127);
            this.comboBoxDivisonAlumno.Name = "comboBoxDivisonAlumno";
            this.comboBoxDivisonAlumno.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDivisonAlumno.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Division";
            // 
            // txtBoxLegajo
            // 
            this.txtBoxLegajo.Location = new System.Drawing.Point(56, 76);
            this.txtBoxLegajo.Name = "txtBoxLegajo";
            this.txtBoxLegajo.Size = new System.Drawing.Size(120, 20);
            this.txtBoxLegajo.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Legajo";
            // 
            // numericUpDownAñoAlumno
            // 
            this.numericUpDownAñoAlumno.Location = new System.Drawing.Point(56, 102);
            this.numericUpDownAñoAlumno.Name = "numericUpDownAñoAlumno";
            this.numericUpDownAñoAlumno.Size = new System.Drawing.Size(120, 20);
            this.numericUpDownAñoAlumno.TabIndex = 13;
            // 
            // txtBoxApellidoAlumno
            // 
            this.txtBoxApellidoAlumno.Location = new System.Drawing.Point(56, 53);
            this.txtBoxApellidoAlumno.Name = "txtBoxApellidoAlumno";
            this.txtBoxApellidoAlumno.Size = new System.Drawing.Size(120, 20);
            this.txtBoxApellidoAlumno.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Apellido";
            // 
            // txtBoxNombreAlumno
            // 
            this.txtBoxNombreAlumno.Location = new System.Drawing.Point(56, 27);
            this.txtBoxNombreAlumno.Name = "txtBoxNombreAlumno";
            this.txtBoxNombreAlumno.Size = new System.Drawing.Size(120, 20);
            this.txtBoxNombreAlumno.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Nombre";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Año";
            // 
            // btnCrearCurso
            // 
            this.btnCrearCurso.Location = new System.Drawing.Point(21, 214);
            this.btnCrearCurso.Name = "btnCrearCurso";
            this.btnCrearCurso.Size = new System.Drawing.Size(75, 23);
            this.btnCrearCurso.TabIndex = 2;
            this.btnCrearCurso.Text = "Crear Curso";
            this.btnCrearCurso.UseVisualStyleBackColor = true;
            this.btnCrearCurso.Click += new System.EventHandler(this.btnCrearCurso_Click);
            // 
            // brnMostrarCurso
            // 
            this.brnMostrarCurso.Location = new System.Drawing.Point(137, 214);
            this.brnMostrarCurso.Name = "brnMostrarCurso";
            this.brnMostrarCurso.Size = new System.Drawing.Size(75, 23);
            this.brnMostrarCurso.TabIndex = 3;
            this.brnMostrarCurso.Text = "Mostrar";
            this.brnMostrarCurso.UseVisualStyleBackColor = true;
            this.brnMostrarCurso.Click += new System.EventHandler(this.btnMostrarCurso_Click);
            // 
            // btnAgregarAlumno
            // 
            this.btnAgregarAlumno.Location = new System.Drawing.Point(363, 214);
            this.btnAgregarAlumno.Name = "btnAgregarAlumno";
            this.btnAgregarAlumno.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarAlumno.TabIndex = 4;
            this.btnAgregarAlumno.Text = "Agregar";
            this.btnAgregarAlumno.UseVisualStyleBackColor = true;
            this.btnAgregarAlumno.Click += new System.EventHandler(this.btnAgregarAlumno_Click);
            // 
            // richTextBox
            // 
            this.richTextBox.Location = new System.Drawing.Point(12, 244);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(429, 203);
            this.richTextBox.TabIndex = 5;
            this.richTextBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 450);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.btnAgregarAlumno);
            this.Controls.Add(this.brnMostrarCurso);
            this.Controls.Add(this.btnCrearCurso);
            this.Controls.Add(this.groupBoxDatosAlumno);
            this.Controls.Add(this.groupBoxDatosCurso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxDatosCurso.ResumeLayout(false);
            this.groupBoxDatosCurso.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAñoCurso)).EndInit();
            this.groupBoxDatosAlumno.ResumeLayout(false);
            this.groupBoxDatosAlumno.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAñoAlumno)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxDatosCurso;
        private System.Windows.Forms.TextBox txtBoxDniCurso;
        private System.Windows.Forms.DateTimePicker dateTimePickerIngreso;
        private System.Windows.Forms.TextBox txtBoxApellidoCurso;
        private System.Windows.Forms.TextBox txtNombreCurso;
        private System.Windows.Forms.ComboBox comboBoxDivisonCurso;
        private System.Windows.Forms.NumericUpDown numericUpDownAñoCurso;
        private System.Windows.Forms.Label lblDni;
        private System.Windows.Forms.Label lblIngreso;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblDivision;
        private System.Windows.Forms.Label lblAño;
        private System.Windows.Forms.GroupBox groupBoxDatosAlumno;
        private System.Windows.Forms.TextBox txtBoxApellidoAlumno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxNombreAlumno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxLegajo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDownAñoAlumno;
        private System.Windows.Forms.ComboBox comboBoxDivisonAlumno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCrearCurso;
        private System.Windows.Forms.Button brnMostrarCurso;
        private System.Windows.Forms.Button btnAgregarAlumno;
        private System.Windows.Forms.RichTextBox richTextBox;
    }
}

