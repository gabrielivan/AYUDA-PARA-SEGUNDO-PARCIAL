﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formularios
{
    public partial class Formulario2 : Form
    {
        public Formulario2()
        {
            InitializeComponent();
        }

        string palabraUno = "";

        private void BtnMandarPalabraFormDos_Click(object sender, EventArgs e)
        {
            Formulario3 formularioTres = new Formulario3(PalabraDos);
            formularioTres.Visible = true;
            this.Visible = false;
        }

        public string PalabraUno
        {
            set
            {
                this.palabraUno = value;
            }
            get
            {
                return this.palabraUno;
            }
        }

        public string PalabraDos
        {
            get
            {
                return this.PalabraUno + " " + TxtPalabraFormDos.Text;
            }
        }
    }
}
