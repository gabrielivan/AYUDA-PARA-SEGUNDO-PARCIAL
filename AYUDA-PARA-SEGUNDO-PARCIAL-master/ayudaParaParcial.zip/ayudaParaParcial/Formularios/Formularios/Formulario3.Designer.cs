﻿namespace Formularios
{
    partial class Formulario3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblResultado = new System.Windows.Forms.Label();
            this.btnVolverPrimerForm = new System.Windows.Forms.Button();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblResultado
            // 
            this.LblResultado.AutoSize = true;
            this.LblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.LblResultado.Location = new System.Drawing.Point(28, 57);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(475, 39);
            this.LblResultado.TabIndex = 0;
            this.LblResultado.Text = "Resultado de las dos palabras";
            // 
            // btnVolverPrimerForm
            // 
            this.btnVolverPrimerForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnVolverPrimerForm.Location = new System.Drawing.Point(112, 142);
            this.btnVolverPrimerForm.Name = "btnVolverPrimerForm";
            this.btnVolverPrimerForm.Size = new System.Drawing.Size(283, 51);
            this.btnVolverPrimerForm.TabIndex = 1;
            this.btnVolverPrimerForm.Text = "Volver al primer formulario";
            this.btnVolverPrimerForm.UseVisualStyleBackColor = true;
            this.btnVolverPrimerForm.Click += new System.EventHandler(this.btnVolverPrimerForm_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnCerrar.Location = new System.Drawing.Point(112, 199);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(283, 49);
            this.btnCerrar.TabIndex = 2;
            this.btnCerrar.Text = "Cerrar el formulario";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // Formulario3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 260);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.btnVolverPrimerForm);
            this.Controls.Add(this.LblResultado);
            this.Name = "Formulario3";
            this.Text = "Formulario3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.Button btnVolverPrimerForm;
        private System.Windows.Forms.Button btnCerrar;
    }
}