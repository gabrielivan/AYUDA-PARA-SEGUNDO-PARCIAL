﻿namespace Formularios
{
    partial class Formulario2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtPalabraFormDos = new System.Windows.Forms.TextBox();
            this.BtnMandarPalabraFormDos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtPalabraFormDos
            // 
            this.TxtPalabraFormDos.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.TxtPalabraFormDos.Location = new System.Drawing.Point(180, 107);
            this.TxtPalabraFormDos.Name = "TxtPalabraFormDos";
            this.TxtPalabraFormDos.Size = new System.Drawing.Size(189, 45);
            this.TxtPalabraFormDos.TabIndex = 0;
            // 
            // BtnMandarPalabraFormDos
            // 
            this.BtnMandarPalabraFormDos.Location = new System.Drawing.Point(180, 194);
            this.BtnMandarPalabraFormDos.Name = "BtnMandarPalabraFormDos";
            this.BtnMandarPalabraFormDos.Size = new System.Drawing.Size(189, 58);
            this.BtnMandarPalabraFormDos.TabIndex = 1;
            this.BtnMandarPalabraFormDos.Text = "Mandar Segunda Palabra";
            this.BtnMandarPalabraFormDos.UseVisualStyleBackColor = true;
            this.BtnMandarPalabraFormDos.Click += new System.EventHandler(this.BtnMandarPalabraFormDos_Click);
            // 
            // Formulario2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 307);
            this.Controls.Add(this.BtnMandarPalabraFormDos);
            this.Controls.Add(this.TxtPalabraFormDos);
            this.Name = "Formulario2";
            this.Text = "Formulario2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtPalabraFormDos;
        private System.Windows.Forms.Button BtnMandarPalabraFormDos;
    }
}