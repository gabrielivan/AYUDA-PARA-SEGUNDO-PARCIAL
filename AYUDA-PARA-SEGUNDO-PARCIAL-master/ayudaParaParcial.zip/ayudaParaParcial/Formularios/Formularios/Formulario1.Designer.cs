﻿namespace Formularios
{
    partial class Formulario1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnMandarPalabraFormUno = new System.Windows.Forms.Button();
            this.TxtPalabraFormUno = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnMandarPalabraFormUno
            // 
            this.BtnMandarPalabraFormUno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.BtnMandarPalabraFormUno.Location = new System.Drawing.Point(180, 194);
            this.BtnMandarPalabraFormUno.Name = "BtnMandarPalabraFormUno";
            this.BtnMandarPalabraFormUno.Size = new System.Drawing.Size(189, 58);
            this.BtnMandarPalabraFormUno.TabIndex = 0;
            this.BtnMandarPalabraFormUno.Text = "Mandar Palabra";
            this.BtnMandarPalabraFormUno.UseVisualStyleBackColor = true;
            this.BtnMandarPalabraFormUno.Click += new System.EventHandler(this.BtnMandarPalabraFormUno_Click);
            // 
            // TxtPalabraFormUno
            // 
            this.TxtPalabraFormUno.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.TxtPalabraFormUno.Location = new System.Drawing.Point(180, 107);
            this.TxtPalabraFormUno.Name = "TxtPalabraFormUno";
            this.TxtPalabraFormUno.Size = new System.Drawing.Size(189, 45);
            this.TxtPalabraFormUno.TabIndex = 1;
            // 
            // Formulario1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 307);
            this.Controls.Add(this.TxtPalabraFormUno);
            this.Controls.Add(this.BtnMandarPalabraFormUno);
            this.Name = "Formulario1";
            this.Text = "Formulario1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnMandarPalabraFormUno;
        private System.Windows.Forms.TextBox TxtPalabraFormUno;
    }
}

