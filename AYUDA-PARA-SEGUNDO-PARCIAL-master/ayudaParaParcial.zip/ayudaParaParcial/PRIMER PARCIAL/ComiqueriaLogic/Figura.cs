﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Figura : Producto  //LA CLASE FIGURA HEREDA DE LA CLASE PRODUCTO(PADRE).
    {
        ////////////////////////////////////////ATRIBUTOS///////////////////////////////////////////////////

        private double altura;

        ////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////CONSTRUCTORES//////////////////////////////////////////////////

        /// <summary>
        /// Sobrecarga del constructor que no recibe la descripcion y usa este formato("Figura *altura* cm")
        /// donde *altura* corresponde al valor de la altura de la figura.
        /// le manda la descripcion al constructor que si recibe como parametro la descripcion(: this).
        /// </summary>
        /// <param name="stock"></param>
        /// <param name="precio"></param>
        /// <param name="altura"></param>
        public Figura(int stock, double precio, double altura) : this(String.Format("Figura {0} cm", altura) ,stock, precio, altura)
        {

        }

        /// <summary>
        /// inicializa todos los atributos con los parámetros de entrada -> Padre(descripcion, stock, precio) -> propio(altura).
        /// </summary>
        /// <param name="descripcion"></param>
        /// <param name="stock"></param>
        /// <param name="precio"></param>
        /// <param name="altura"></param>
        public Figura(string descripcion, int stock, double precio, double altura) : base(descripcion, stock, precio) //manda los datos a la clase padre.
        {
            this.altura = altura; 
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////METODOS////////////////////////////////////////////////////

        /// <summary>
        /// Sobrecarga del método ToString para devolver los datos del padre(descripcion, stock, precio) y los datos propios(altura).
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.Append("\n Altura: ");
            sb.AppendLine(this.altura.ToString());
            return sb.ToString();
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
