﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComprobantesLogic;

namespace ComiqueriaLogic
{
    public class Comiqueria
    {
        /////////////////////////////////////ATRIBUTOS/////////////////////////////////////////////////////

        private List<Producto> productos;
        private List<Venta> ventas;
        static Stack<Comprobante> comprobantes;

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////CONSTRUCTORES/////////////////////////////////////////////////

        /// <summary>
        /// Constructor instancia sus 2 atributos de tipo List
        /// </summary>
        public Comiqueria()
        {
            this.productos = new List<Producto>();
            this.ventas = new List<Venta>();
        }

        static Comiqueria()
        {
            comprobantes = new Stack<Comprobante>();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////INDEXADORES///////////////////////////////////////////////////

        /// <summary>
        /// indexador que recibe como parámetro un código de tipo Guid 
        /// y devuelve el producto que corresponda con el código del producto que este en la lista de productos(atributo productos).
        /// Si no encuentra ningún producto devolverá null.
        /// </summary>
        /// <param name="codigo"></param>
        /// <returns></returns>
        public Producto this[Guid codigo]
        {
            get
            {
                foreach (Producto p in this.productos)//recorro la lista de productos
                {
                    if(this.productos != null)//pregunto si la lista es distinta de null
                    {
                        Guid guidAux = (Guid)p; //obtengo el codigo del producto
                        if (guidAux == codigo) //comparo el codigo actual(guidAux con el que recibi por parametro(codigo))
                        {
                            return p; //retorno el producto
                        }
                    }
                }
                return null; //si no retorne el producto retorno null
            }
        }

        public List<Comprobante> this[Producto producto, bool ordenar]
        {
            get
            {
                List<Comprobante> comprobantes = new List<Comprobante>();

                foreach (Comprobante c in comprobantes)
                {
                    Producto productoAuxiliar = (Producto)c.Venta;

                    foreach (Producto p in productos)
                    {
                        Guid codigoAux = (Guid)p;

                        if (codigoAux == (Guid)producto && codigoAux == (Guid)productoAuxiliar)
                        {
                            if (ordenar)
                            {
                                comprobantes.Sort();
                                comprobantes.Reverse();
                            }
                            else
                            {
                                return comprobantes;
                            }
                        }
                    }

                }

                return comprobantes;

            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////METODOS///////////////////////////////////////////////////////

        /// <summary>
        /// Metodo que devuelve un Dictionary de tipo (Guid, string). 
        /// Cada elemento del diccionario corresponderá con cada producto en la lista de productos. 
        /// La key será el código del producto(Guid) y el valor sera la descripción del producto(string).
        /// </summary>
        /// <returns></returns>
        public Dictionary<Guid, string> Listarproductos()
        {
            Dictionary<Guid, string> diccionario = new Dictionary<Guid, string>();//instancio el diccionario
            foreach (Producto p in this.productos) //recorro la lista de productos
            {
                if (productos != null)//pregunto si la lista es distinta de null
                {
                    Guid guidAux = (Guid)p; //obtengo el codigo del producto actual
                    diccionario.Add(guidAux, p.Descripcion); //agrego al diccionario el producto por (Key,value) -> (guidAux, p.Descripcion).
                }
            }
            return diccionario; //retorno el diccionario.
        }

        /// <summary>
        /// devuelve un string conteniendo la descripción breve de cada venta en la lista de ventas. 
        /// Una descripción por línea.
        /// La lista se ordena por fecha de la más reciente a la más antigua
        /// </summary>
        /// <returns></returns>
        public string ListarVentas()
        {
            StringBuilder sb = new StringBuilder();

            if (this.ventas != null) //pregunto si ventas en distinto a null
            {
                this.ventas.Sort(CompararLasVentas); //ordeno las ventas de la más reciente a la más antigua con la funcion(CompararLasVentas).
            }
            
            foreach (Venta v in ventas) //recorro las ventas
            {
                if (this.ventas != null) //pregunto si ventas en distinto a null
                {
                    sb.AppendLine(v.ObtenerDescripcionBreve()); //obtengo la descripcion breve de cada venta
                    sb.Append("\n");
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// metodo que tiene una sobrecarga que sólo recibe un producto osea sin el parametro (cantidad). 
        /// Llama a la sobrecarga que recibe(producto y cantidad) pasándole como parametro el valor (1) al parametro cantidad del otro metodo.
        /// </summary>
        /// <param name="producto"></param>
        public void Vender(Producto producto)
        {
            if (producto != null)
            {
                this.Vender(producto, 1);
            }
        }

        /// <summary>
        /// Agrega una nueva venta a la lista de ventas.
        /// </summary>
        /// <param name="producto"></param>
        /// <param name="cantidad"></param>
        public void Vender(Producto producto, int cantidad)
        {
            if (producto != null) // pregunto si el producto que recibi no es null.
            {
                Venta venta = new Venta(producto, cantidad); //instancio una venta con el correspondiente constructor
                ventas.Add(venta); // le agrego una venta.
            }
        }

        /// <summary>
        /// Metodo que compara las ventas por su fecha devolviendo 1 si la primer venta tiene una fecha mayor a la fecha de la segunda venta
        /// sino devuelve -1 si la primer venta tiene una fecha menor a la fecha de la segunda venta
        /// sino retorna 0 que es que son iguales.
        /// </summary>
        /// <param name="ventaUno"></param>
        /// <param name="ventaDos"></param>
        /// <returns></returns>
        private int CompararLasVentas(Venta ventaUno, Venta ventaDos)
        {
            if (ventaUno.Fecha > ventaDos.Fecha)
            {
                return 1;
            }
            else if (ventaUno.Fecha < ventaDos.Fecha)
            {
                return -1;
            }
            return 0;
        }

        public bool AgregarComprobante(Comprobante comprobante)
        {
            bool retorno = false;

            if (this != comprobante)
            {
                comprobantes.Push(comprobante);
                retorno = true;
            }
            return retorno;
        }

        private bool AgregarComprobante(Venta venta)
        {
            bool retorno = false;

            Factura factura = new Factura(venta, Factura.TipoFactura.B);

            comprobantes.Push(factura);

            return retorno;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////SOBRECARGAS////////////////////////////////////////////////////

        /// <summary>
        /// verifica si el producto se encuentra en la lista de productos(comiqueria.productos) comparando la descripción. 
        /// Si dos productos tienen la misma descripción son el mismo producto.
        /// </summary>
        /// <param name="comiqueria"></param>
        /// <param name="producto"></param>
        /// <returns></returns>
        public static bool operator ==(Comiqueria comiqueria, Producto producto)
        {
            bool retorno = false;

            foreach (Producto p in comiqueria.productos) //recorro la lista de productos de la clase comiqueria(segundo parametro).
            {
                if (p != null && comiqueria.productos != null && producto != null) //valido que el producto, la lista de productos y el producto auxiliar sean distintos de null.
                {
                    if (producto.Descripcion == p.Descripcion) // pregunto si el producto que yo recibi por parametro tiene la misma descripcion que
                    {                                          // el producto que esta en la lista de productos(de comiqueria, recibida por parametro).
                        retorno = true;
                    }
                }
            }
            return retorno;
        }

        public static bool operator !=(Comiqueria comiqueria, Producto producto)
        {

            return !(comiqueria == producto);
        }

        /// <summary>
        /// agrega un producto a la lista de productos siempre que el mismo ya no exista en la lista.
        /// </summary>
        /// <param name="comiqueria"></param>
        /// <param name="producto"></param>
        /// <returns></returns>
        public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
        {
            if (comiqueria != producto) //reutilizo el !=(lo contrario a la sobrecarga del ==) -> para preguntar si el producto que recibi por parametro no esta en la lista de productos de comiqueria.
            {
                comiqueria.productos.Add(producto); //agrego el producto a la lista de productos de comiqueria.
            }

            return comiqueria; //retorno la comiqueria.

        }

        public static bool operator ==(Comiqueria comiqueria, Comprobante comprobante)
        {
            bool retorno = false;

            foreach (Comprobante comprobanteAux in comprobantes)
            {
                if (comprobanteAux == comprobante)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Comiqueria comiqueria, Comprobante comprobante)
        {
            return !(comiqueria == comprobante);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

    }
}
