﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComiqueriaLogic;

namespace ComprobantesLogic
{
    public abstract class Comprobante
    {
        protected DateTime fechaEmision;
        private Venta venta;

        /// <summary>
        /// Propiedad de solo lectura que publica el atributo venta.
        /// Es accesible desde el mismo ensamblado (Internal).
        /// </summary>
        internal Venta Venta
        {
            get
            {
                return this.venta;
            }
        }

        /// <summary>
        /// Inicializa el campo fechaEmision con la Propiedad "Fecha" del atributo venta recibido por parametro.
        /// Ademas el atributo venta los inicializa con la venta recibida por parametro.
        /// </summary>
        /// <param name="venta"></param>
        public Comprobante(Venta venta)
        {
            this.fechaEmision = venta.Fecha;
            this.venta = venta;
        }

        /// <summary>
        /// Devuelve true si el obj es de tipo Comprobante && la fecha de emision
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            return obj is Comprobante & obj is DateTime;
        }

        /// <summary>
        /// Metodo abstracto implementara en sus derivadas.
        /// </summary>
        /// <returns></returns>
        public abstract string GenerarComprobante();

    }
}
