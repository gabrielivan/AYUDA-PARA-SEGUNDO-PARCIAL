using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public abstract class Producto //PRODUCTO ES UNA CLASE ABSTRACTA (PADRE)
    {
        /////////////////////////////////////ATRIBUTOS///////////////////////////////////////////////////

        private Guid codigo;
        private string descripcion;
        private double precio;
        private int stock;

        /////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////CONSTRUCTORES///////////////////////////////////////////////

        /// <summary>
        /// Constructor protegido. Inicializar� el atributo codigo con el m�todo est�tico NewGuid de la clase Guid. 
        /// Inicializara el resto de los campos con los par�metros de entrada (descripcion, stock, precio).
        /// </summary>
        /// <param name="descripcion"></param>
        /// <param name="stock"></param>
        /// <param name="precio"></param>

        protected Producto(string descripcion, int stock, double precio)
        {
            this.codigo = Guid.NewGuid();
            this.descripcion = descripcion;
            this.Stock = stock;
            this.precio = precio;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////


        ///////////////////////////////////////PROPIEDADES//////////////////////////////////////////////

        /// <summary>
        /// Propiedad de solo lectura. 
        /// </summary>
        public string Descripcion
        {
            get
            {
                return this.descripcion;
            }
        }

        /// <summary>
        /// Propiedad de lectura y escritura. 
        /// </summary>
        public double Precio
        {
            get
            {
                return this.precio;
            }
            set
            {
                if (value >= 1)
                {
                    this.precio = value;
                }
            }
        }

        /// <summary>
        /// Propiedad de lectura y escritura. 
        /// Valida que el stock ingresado sea mayor o igual a cero, sino no lo actualizar�
        /// </summary>
        public int Stock
        {
            get
            {
                return this.stock;
            }
            set
            {
                if (value >= 0)
                {
                    this.stock = value;
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////SOBRECARGAS//////////////////////////////////////////////

        /// <summary>
        /// Sobrecarga del m�todo ToString para devolver un string con los datos de un producto: descripci�n, c�digo, precio y stock
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Descripcion: ");
            sb.AppendLine(this.Descripcion);
            sb.Append("Stock: ");
            sb.AppendLine(this.Stock.ToString());
            sb.Append("Precio: ");
            sb.AppendLine(String.Format("${0:#,0.00}", this.Precio)); //Le da un formato de 2 decimales(2.00).
            sb.Append("Codigo: ");
            sb.AppendLine(this.codigo.ToString());
            return sb.ToString();
        }

        /// <summary>
        /// M�todo de conversi�n expl�cita transforma un producto en su c�digo(Tipo Guid).
        /// </summary>
        /// <param name="p"></param>
        public static explicit operator Guid(Producto p)
        {
            return p.codigo;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
