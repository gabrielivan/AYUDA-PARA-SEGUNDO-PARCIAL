﻿using System;
using System.Text;

namespace ComiqueriaLogic
{
    public sealed class Venta // LA CLASE VENTA ES UNA CLASE SELLADA NO HEREDA DE NADIE.
    {
        /////////////////////////////////////ATRIBUTOS///////////////////////////////////////////////////

        private DateTime fecha; //atributo de tipo DateTime.
        static int porcentajeIva; //atributo estático.
        private double precioFinal;
        private Producto producto;// //atributo de tipo Producto(clase).
        private int cantidad;

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////CONSTRUCTORES//////////////////////////////////////////////

        /// <summary>
        /// Constructor estatico inicializará el atributo estatico (porcentajeIva) en 21.
        /// </summary>
        static Venta()
        {
            porcentajeIva = 21;
        }

        /// <summary>
        /// Constructor internal de instancia sólo es accesible desde el mismo ensamblado
        /// inicializa el campo producto y llamará al método Vender pasándole la cantidad(segundo parametro)indicada como argumento.
        /// </summary>
        /// <param name="producto"></param>
        /// <param name="cantidad"></param>
        internal Venta(Producto producto, int cantidad)
        {

            this.cantidad = cantidad;

            if (producto != null)
            {
                this.producto = producto; //inicializa el atributo producto.
                Vender(cantidad);
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////PROPIEDADES/////////////////////////////////////////////////

        /// <summary>
        /// Propiedad internal sólo es accesible desde el mismo ensamblado, devuelve la fecha de la venta
        /// </summary>
        internal DateTime Fecha 
        {
            get
            {
                return this.fecha;
            }
        }

        public int Cantidad
        {
            get
            {
                return this.cantidad;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////METODOS/////////////////////////////////////////////////////

        /// <summary>
        /// Método estático y público
        /// Calcula el precio final multiplicando el precio precioUnidad(primer parametro) por la cantidad(segundo parametro) comprada, 
        /// y a este resultado le aplicará el porcentaje de IVA(atributo porcentajeIva).
        /// </summary>
        /// <param name="precioUnidad"></param>
        /// <param name="cantidad"></param>
        /// <returns></returns>
        public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
        {
            double precioFinal = (precioUnidad * porcentajeIva) / 100;
            precioFinal = precioFinal + precioUnidad * cantidad;
            return precioFinal;
        }

        /// <summary>
        /// Método que devuelve un string breve y en una sola línea indicando fecha, descripción del producto y precio final(con 2 decimales)
        /// </summary>
        /// <returns></returns>
        public string ObtenerDescripcionBreve()
        {
            string precioFinalConDosDecimales = String.Format("${0:#,0.00}", this.precioFinal); //formato de 2 decimales(2.00)
            return String.Format("fecha {0} - descripcion {1} - precioFinal {2}", this.Fecha.ToString(), this.producto.Descripcion, precioFinalConDosDecimales);
        }

        /// <summary>
        /// Método privado y de instancia
        /// Le resta al stock del atributo producto la cantidad que le pasaron por parámetro.
        /// Inicializa el atributo fecha con la fecha actual completa.
        /// Inicializa el atributo precioFinal con el valor retornado por el método CalcularPrecioFinal, 
        /// al cual se le pasa (el precio del atributo producto y la cantidad recibida por parametro).
        /// </summary>
        /// <param name="cantidad"></param>
        private void Vender(int cantidad)
        {
            this.producto.Stock = this.producto.Stock - cantidad;
            
            this.fecha = DateTime.Now;

            this.precioFinal = CalcularPrecioFinal(producto.Precio, cantidad);
        }

        /// <summary>
        /// Devuelve el producto correspondiente a esa Venta.
        /// </summary>
        /// <param name="venta"></param>
        public static explicit operator Producto(Venta venta)
        {
            return venta.producto;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
