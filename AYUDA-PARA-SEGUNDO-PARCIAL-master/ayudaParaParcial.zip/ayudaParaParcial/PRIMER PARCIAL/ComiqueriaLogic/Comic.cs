﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comic : Producto // LA CLASE COMIC HEREDA DE LA CLASE PRODUCTO(PADRE).
  {
        ////////////////////////////////////////ATRIBUTOS///////////////////////////////////////////////////

        private string autor;
        private TipoComic tipoComic;

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////CONSTRUCTORES//////////////////////////////////////////////

        /// <summary>
        /// Inicializa los atributos con los parametros de entrada(descripcion, stock, precio, autor, tipocomic)
        /// </summary>
        /// <param name="descripcion"></param>
        /// <param name="stock"></param>
        /// <param name="precio"></param>
        /// <param name="autor"></param>
        /// <param name="tipocomic"></param>
        public Comic(string descripcion, int stock, double precio, string autor, TipoComic tipocomic) : base(descripcion, stock, precio) //le manda al padre los 3 atributos que comparten
        {
            //Setea los 2 atributos que no comparte con el padre
            this.autor = autor;
            this.tipoComic = tipocomic;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////SOBRECARGAS////////////////////////////////////////////////

        /// <summary>
        /// Sobrecarga del método ToString para devolver los datos del padre(descripcion, stock, precio) y los datos propios(autor, tipocomic)
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.Append("\n Autor: ");
            sb.AppendLine(this.autor);
            sb.Append("TipoComic: ");
            sb.AppendLine(this.tipoComic.ToString());
            return sb.ToString();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////ENUMERADOS/////////////////////////////////////////////////

        public enum TipoComic
        {
            Occidental,
            Oriental
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
