﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComiqueriaLogic;

namespace ComprobantesLogic
{
    public class Factura : Comprobante
    {
        private DateTime fechaVencimiento;
        private TipoFactura tipoFactura;

        public override bool Equals(object obj)
        {
            return obj is Factura;
        }

        public Factura(Venta venta, int diasParaVencimiento, TipoFactura tipoFactura) : base(venta)
        {
            this.fechaVencimiento = DateTime.Now;
            this.tipoFactura = tipoFactura;
        }

        public Factura(Venta venta,TipoFactura tipoFactura) : this(venta, 15, tipoFactura)
        {

        }

        public override string GenerarComprobante()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Factura {0}", this.tipoFactura);
            sb.AppendFormat("Fecha Emision {0}", this.fechaEmision);
            sb.AppendFormat("Fecha Vencimiento {0}", this.fechaVencimiento);
            Producto producto = (Producto)this.Venta;
            sb.AppendFormat("Producto {0}", producto.Descripcion);
            sb.AppendFormat("Cantidad {0}", this.Venta.Cantidad);
            sb.AppendFormat("Precio Unitario {0}", producto.Precio);
            sb.AppendFormat("Subtotal {0}", producto.Precio * this.Venta.Cantidad);

            return sb.ToString();
        }

        public enum TipoFactura
        {
            A,
            B,
            C,
            E
        }
    }
}
