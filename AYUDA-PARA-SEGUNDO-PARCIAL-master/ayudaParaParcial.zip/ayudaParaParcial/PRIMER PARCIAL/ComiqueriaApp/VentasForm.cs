﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;
using ComiqueriaApp; 

namespace ComiqueriaApp
{
    public partial class VentasForm : Form
    {
        /////////////////////////////////////ATRIBUTOS/////////////////////////////////////////////////////

        private Producto producto;
        private Comiqueria comiqueria;

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////CONSTRUCTORES/////////////////////////////////////////////////

        public VentasForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// seteo con los valores recibidos a mis 2 atributos (producto, comiqueria).
        /// mediante sus respectivas propiedades.
        /// </summary>
        /// <param name="productoSeleccionado"></param>
        /// <param name="comiqueria"></param>
        public VentasForm(Producto productoSeleccionado, Comiqueria comiqueria) : this()
        {
            this.ProductoForm = productoSeleccionado;
            this.ComiqueriaForm = comiqueria;
            lblDescripcion.Text = productoSeleccionado.Descripcion; // hago que al principio de todo el label de descripcion sea igual a la descripcion del producto que recibi por parametro.
            lblPrecioFinal2.Text = Venta.CalcularPrecioFinal(ProductoForm.Precio, (int)numericUpDownCantidad.Value).ToString(); //Calculo al principio el precio final por defecto que es 1, 
                                                                                                                                //con la funcion CalcularPrecioFinal y le mando el valor que tengo en el numericUpDown al principio de todo(1).
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////PROPIEDADES////////////////////////////////////////////////////

        /// <summary>
        /// Propiedad de lectura y escritura.
        /// la uso para que guarde el producto que recibo en el constructor y me lo pueda retornar.
        /// </summary>
        public Producto ProductoForm
        {
            get
            {
                return this.producto;
            }
            set
            {
                this.producto = value;
            }
        }

        /// <summary>
        /// Propiedad de lectura y escritura.
        /// la uso para que guarde la comiqueria que recibo en el constructor y me la pueda retornar.
        /// </summary>
        public Comiqueria ComiqueriaForm
        {
            get
            {
                return this.comiqueria;
            }
            set
            {
                this.comiqueria = value;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////METODOS///////////////////////////////////////////////////

        /// <summary>
        /// Cierra el Form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Valida que la cantidad que se va a vender sea menor o igual al stock disponible(el valor del numericUpDown).
        /// Si es mayor muestra un MessageBox informando al usuario que superó el stock disponible y debe disminuir la cantidad de unidades a vender.
        /// Si es menor o igual se vende el producto.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVender_Click(object sender, EventArgs e)
        {
            if (numericUpDownCantidad.Value <= ProductoForm.Stock)
            {
                ComiqueriaForm.Vender(ProductoForm, (int)numericUpDownCantidad.Value);
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Superó el stock disponible y debe disminuir la cantidad de unidades a vender", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Cada vez que se indica una nueva cantidad se actualiza el precio final
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void numericUpDownCantidad_ValueChanged(object sender, EventArgs e)
        {
            double precioFinal = Venta.CalcularPrecioFinal(ProductoForm.Precio, (int)numericUpDownCantidad.Value); //obtengo el precio final mediante la funcion CalcularPrecioFinal de la clase Venta 
                                                                                                                   //y le mando el precio del producto(atributo) y el value del numericUpDown que seria la cantidad.
            lblPrecioFinal2.Text = precioFinal.ToString();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
    }
}
