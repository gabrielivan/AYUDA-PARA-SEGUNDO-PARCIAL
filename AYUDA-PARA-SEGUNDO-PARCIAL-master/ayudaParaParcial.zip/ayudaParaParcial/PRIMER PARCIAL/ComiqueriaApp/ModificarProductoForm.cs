﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaApp;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
    public partial class ModificarProductoForm : Form
    {
        Producto producto;

        public ModificarProductoForm()
        {
            InitializeComponent();
        }

        public ModificarProductoForm(Producto productoSeleccionado): this()
        {
            lblDescripcion.Text = productoSeleccionado.Descripcion;
            txtPrecioActual.Text = productoSeleccionado.Precio.ToString();
            producto = productoSeleccionado;
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            double precioValidado;
            if (Double.TryParse(txtNuevoPrecio.Text, out precioValidado))
            {
                producto.Precio = precioValidado;
                MessageBox.Show("Confirmacion de usuario: ", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                this.Close();
            }
            else
            {
                lblError.Text = "Error.Debe ingresar un precio valido.";
            }
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
