﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        private const int cantidadMaximaJugadores = 6;
        private DirectorTecnico directorTecnico;
        private List<Jugador> jugadores;
        private string nombre;

        private Equipo()
        {
            jugadores = new List<Jugador>();
        }

        public Equipo(string nombre): this()
        {
            this.nombre = nombre;
        }

        public DirectorTecnico DirectorTecnico
        {
            set
            {
                if (value.ValidarAptitud())
                {
                    this.directorTecnico = (value);
                }

            }
        }

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }

        public static bool ValidarEquipo(Equipo e)
        {
            bool retorno = false;
            bool jugadorCentral = false;
            bool jugadorDefensor = false;
            bool jugadorDelantero = false;
            int contadorArquero = 0;

            if (e.jugadores != null)
            {
                foreach (Jugador jugador in e.jugadores)
                {
                    if (jugador.Posicion == Posicion.Central)
                    {
                        jugadorCentral = true;
                    }
                    else if (jugador.Posicion == Posicion.Arquero)
                    {
                        contadorArquero++;
                    }
                    else if (jugador.Posicion == Posicion.Defensor)
                    {
                        jugadorDefensor = true;
                    }
                    else if (jugador.Posicion == Posicion.Delantero)
                    {
                        jugadorDelantero = true;
                    }
                }
            }

            if (e.directorTecnico != null && jugadorCentral && (contadorArquero == 1)  && jugadorDefensor && jugadorDelantero && cantidadMaximaJugadores == 6)
            {
                retorno = true;
            }

            return retorno;
        }

        public static explicit operator string(Equipo e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("El nombre del equipo es: " + e.nombre);

            if (e.directorTecnico != null)
            {
                sb.AppendLine("Datos Del Director Tecnico: " + e.directorTecnico.Mostrar());
            }
            else
            {
                sb.AppendLine("Sin DT asignado");
            }

            if (e.jugadores != null)
            {
                foreach (var jugador in e.jugadores)
                {
                    sb.AppendLine(jugador.Mostrar());
                }
            }

            return sb.ToString();
            
        }

        public static bool operator !=(Equipo e, Jugador j)
        {
            return !(e == j);
        }

        public static bool operator ==(Equipo e, Jugador j)
        {
            if (e.jugadores != null)
            {
                return e.jugadores.Contains(j);
            }
            else
            {
                return false;
            }

        }

        public static Equipo operator +(Equipo e, Jugador j)
        {
            if (e != j && (e.jugadores.Count < cantidadMaximaJugadores) && j.ValidarAptitud())
            {
                e.jugadores.Add(j);
            }

            return e;
        }

    }
}
