﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico : Persona
    {
        private int añosExperiencia;

        public DirectorTecnico(string nombre, string apellido, int edad, int dni, int añosExperiencia) : base(nombre, apellido, edad, dni)
        {
            this.AñosExperiencia = añosExperiencia;
        }

        public int AñosExperiencia
        {
            set
            {
                this.añosExperiencia = (value);
            }
            get
            {
                return this.añosExperiencia;
            }
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.Mostrar());
            sb.Append("Años de Experiencia: " + this.AñosExperiencia);
            return sb.ToString();
        }

        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if (this.Edad < 65 && this.AñosExperiencia > 2)
            {
                retorno = true;
            }
            return retorno;
        }

    }
}
